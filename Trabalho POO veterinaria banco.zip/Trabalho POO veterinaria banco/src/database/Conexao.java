package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection conectar(){
        String url = "jdbc:mysql://localhost:3306/petcare";
        String usuario = "root";
        String senha = "080326";

        try{
            Connection conexao = DriverManager.getConnection(
                    url, usuario, senha
            );

            System.out.println("Conexão realizada com sucesso");

            return conexao;
        } catch (SQLException e) {
            System.out.println("Erro ao conectar:" + e.getMessage());
            return null;
        }

    }
}
