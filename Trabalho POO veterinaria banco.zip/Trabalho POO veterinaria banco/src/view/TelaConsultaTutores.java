package view;

import dao.TutorDAO;
import model.Tutor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaConsultaTutores extends JFrame {

    public TelaConsultaTutores() {

        setTitle("PetCare - Consultar Tutores");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        // Colunas da tabela
        String[] colunas = {"ID", "Nome", "Telefone"};

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }
        };

        // Buscar tutores no MySQL
        TutorDAO tutorDAO = new TutorDAO();
        List<Tutor> tutores = tutorDAO.listar();

        for (Tutor tutor : tutores) {

            Object[] linha = {
                    tutor.getId(),
                    tutor.getNome(),
                    tutor.getTelefone()
            };

            modelo.addRow(linha);
        }

        // Criar tabela
        JTable tabela = new JTable(modelo);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(tabela);
        add(scroll, BorderLayout.CENTER);

        // Botões
        JButton btnEditar = new JButton("Editar Tutor");
        JButton btnExcluir = new JButton("Excluir Tutor");

        btnExcluir.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione um tutor para excluir!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idTutor = (int) modelo.getValueAt(linhaModelo, 0);

            TutorDAO dao = new TutorDAO();

            // Verificar se o tutor possui animais
            if (dao.possuiAnimais(idTutor)) {
                JOptionPane.showMessageDialog(this,
                        "Não é possível excluir este tutor!\n" +
                                "Ele possui animais cadastrados.");
                return;
            }

            // Solicitar confirmação
            int confirmacao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente excluir este tutor?",
                    "Confirmar Exclusão",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirmacao == JOptionPane.YES_OPTION) {

                if (dao.excluir(idTutor)) {

                    modelo.removeRow(linhaModelo);

                    tutores.removeIf(tutor -> tutor.getId() == idTutor);

                    JOptionPane.showMessageDialog(this,
                            "Tutor excluído com sucesso!");

                } else {
                    JOptionPane.showMessageDialog(this,
                            "Erro ao excluir tutor!");
                }
            }
        });

        JPanel painelBotoes = new JPanel();
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);

        add(painelBotoes, BorderLayout.SOUTH);

        btnEditar.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione um tutor para editar!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idTutor = (int) modelo.getValueAt(linhaModelo, 0);

            Tutor tutorSelecionado = null;

            for (Tutor tutor : tutores) {
                if (tutor.getId() == idTutor) {
                    tutorSelecionado = tutor;
                    break;
                }
            }

            if (tutorSelecionado == null) {
                JOptionPane.showMessageDialog(this,
                        "Tutor não encontrado!");
                return;
            }

            final Tutor tutorEdicao = tutorSelecionado;

            TelaEditarTutor telaEdicao = new TelaEditarTutor(tutorEdicao, () -> {

                modelo.setValueAt(tutorEdicao.getNome(), linhaModelo, 1);
                modelo.setValueAt(tutorEdicao.getTelefone(), linhaModelo, 2);

            });

            telaEdicao.setVisible(true);

        });
    }
}