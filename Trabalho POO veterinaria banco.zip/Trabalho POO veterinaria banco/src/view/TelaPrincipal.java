package view;

import javax.swing.*;
import java.awt.*;

public class TelaPrincipal extends JFrame {

    public TelaPrincipal(){
        setTitle("PetCare");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(8, 1, 10, 20));
        painel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));

        JLabel titulo = new JLabel("PetCare", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 28));

        JButton btnCadastrar = new JButton("Cadastrar Animal");
        JButton btnConsultar = new JButton("Consultar Animais");
        JButton btnCadastrarTutor = new JButton("Cadastrar Tutor");
        JButton btnConsultarTutores = new JButton("Consultar Tutores");
        JButton btnCadastrarEspecie = new JButton("Cadastrar Espécie");
        JButton btnConsultarEspecies = new JButton("Consultar Espécies");
        JButton btnCadastrarRaca = new JButton("Cadastrar Raça");
        JButton btnConsultarRacas = new JButton("Consultar Raças");

        btnConsultarEspecies.addActionListener(e -> {

            TelaConsultaEspecies tela = new TelaConsultaEspecies();

            tela.setVisible(true);

        });

        btnCadastrarTutor.addActionListener(e -> {
            TelaCadastroTutor tela = new TelaCadastroTutor();
            tela.setVisible(true);
        });

        btnConsultarTutores.addActionListener(e -> {

            TelaConsultaTutores tela = new TelaConsultaTutores();
            tela.setVisible(true);

        });

        btnConsultar.addActionListener(e -> {
            TelaConsultaAnimais tela = new TelaConsultaAnimais();
            tela.setVisible(true);
        });

        btnCadastrar.addActionListener(e -> {
            TelaCadastroAnimal telaCadastro = new TelaCadastroAnimal();
            telaCadastro.setVisible(true);
        });

        btnCadastrarEspecie.addActionListener(e -> {
            TelaCadastroEspecie tela = new TelaCadastroEspecie();
            tela.setVisible(true);
        });

        btnCadastrarRaca.addActionListener(e -> {

            TelaCadastroRaca tela = new TelaCadastroRaca();

            tela.setVisible(true);

        });

        btnConsultarRacas.addActionListener(e -> {

            TelaConsultaRacas tela = new TelaConsultaRacas();

            tela.setVisible(true);

        });

        painel.add(titulo);
        painel.add(btnCadastrar);
        painel.add(btnConsultar);
        painel.add(btnCadastrarTutor);
        painel.add(btnConsultarTutores);
        painel.add(btnCadastrarEspecie);
        painel.add(btnConsultarEspecies);
        painel.add(btnCadastrarRaca);
        painel.add(btnConsultarRacas);

        add(painel);

    }
}
