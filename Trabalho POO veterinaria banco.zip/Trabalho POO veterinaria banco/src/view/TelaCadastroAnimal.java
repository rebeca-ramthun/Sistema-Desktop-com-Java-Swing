package view;

import dao.EspecieDAO;
import dao.RacaDAO;
import model.Especie;
import model.Raca;
import java.util.List;

import javax.swing.*;
import java.awt.*;
import controller.AnimalController;


public class TelaCadastroAnimal extends JFrame {

    public TelaCadastroAnimal() {
        setTitle("PetCare - Cadastro Animal");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(9, 2, 10, 10));
        painel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JComboBox<String> campoEspecie = new JComboBox<>();
        JComboBox<String> campoRaca = new JComboBox<>();
        JTextField campoNome = new JTextField();

        campoEspecie.addItem("Selecione uma espécie");
        campoRaca.addItem("Selecione uma raça");

// Buscar espécies cadastradas no MySQL
        EspecieDAO especieDAO = new EspecieDAO();
        List<Especie> especies = especieDAO.listar();

        for (Especie especie : especies) {
            campoEspecie.addItem(especie.getNome());
        }

// Atualizar as raças quando mudar a espécie
        campoEspecie.addActionListener(e -> {

            campoRaca.removeAllItems();
            campoRaca.addItem("Selecione uma raça");

            int indice = campoEspecie.getSelectedIndex();

            if (indice <= 0) {
                return;
            }

            Especie especieSelecionada = especies.get(indice - 1);

            RacaDAO racaDAO = new RacaDAO();

            List<Raca> racas = racaDAO.listarPorEspecie(
                    especieSelecionada.getId()
            );
            System.out.println("Espécie selecionada: "
                    + especieSelecionada.getNome());

            System.out.println("ID da espécie: "
                    + especieSelecionada.getId());

            System.out.println("Quantidade de raças encontradas: "
                    + racas.size());

            for (Raca raca : racas) {
                System.out.println("Raça encontrada: " + raca.getNome());
            }

            for (Raca raca : racas) {
                campoRaca.addItem(raca.getNome());
            }
        });

        JComboBox<String> campoSexo = new JComboBox<>(
                new String[]{"Macho", "Fêmea"}
        );
        JTextField campoCor = new JTextField();
        JTextField campoNascimento = new JTextField();
        JTextField campoTutor = new JTextField();
        JTextField campoTelefone = new JTextField();

        painel.add(new JLabel("Nome:"));
        painel.add(campoNome);

        painel.add(new JLabel("Espécie:"));
        painel.add(campoEspecie);

        painel.add(new JLabel("Raça:"));
        painel.add(campoRaca);

        painel.add(new JLabel("Sexo:"));
        painel.add(campoSexo);

        painel.add(new JLabel("Cor:"));
        painel.add(campoCor);

        painel.add(new JLabel("Nascimento (AAAA-MM-DD):"));
        painel.add(campoNascimento);

        painel.add(new JLabel("Tutor:"));
        painel.add(campoTutor);

        painel.add(new JLabel("Telefone:"));
        painel.add(campoTelefone);

        JButton btnLimpar = new JButton("Limpar");
        JButton btnCadastrar = new JButton("Cadastrar");
        btnLimpar.addActionListener(e -> {
            campoNome.setText("");
            campoEspecie.setSelectedIndex(0);
            campoRaca.setSelectedIndex(0);
            campoSexo.setSelectedIndex(0);
            campoCor.setText("");
            campoNascimento.setText("");
            campoTutor.setText("");
            campoTelefone.setText("");
        });
        btnCadastrar.addActionListener(e -> {

            AnimalController controller = new AnimalController();

            String mensagem = controller.cadastrarAnimal(
                    campoNome.getText().trim(),
                    campoEspecie.getSelectedItem().toString(),
                    campoRaca.getSelectedItem() != null
                            ? campoRaca.getSelectedItem().toString()
                            : "",
                    campoSexo.getSelectedItem().toString(),
                    campoCor.getText().trim(),
                    campoNascimento.getText().trim(),
                    campoTutor.getText().trim(),
                    campoTelefone.getText().trim()
            );

            JOptionPane.showMessageDialog(this, mensagem);
        });

        painel.add(btnLimpar);
        painel.add(btnCadastrar);

        add(painel);
    }
}
