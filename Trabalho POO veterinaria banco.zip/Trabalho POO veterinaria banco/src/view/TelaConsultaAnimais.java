package view;

import dao.AnimalDAO;
import model.Animal;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;

public class TelaConsultaAnimais extends JFrame {

    public TelaConsultaAnimais() {
        setTitle("PetCare - Consultar Animais");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // Nomes das colunas
        String[] colunas = {
                "ID", "Nome", "Espécie", "Raça",
                "Sexo", "Cor", "Nascimento", "Tutor"
        };

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0);

        AnimalDAO animalDAO = new AnimalDAO();

        List<Animal> animais = animalDAO.listar();

        for (Animal animal : animais) {

            Object[] linha = {
                    animal.getId(),
                    animal.getNome(),
                    animal.getEspecie().getNome(),
                    animal.getRaca().getNome(),
                    animal.getSexo(),
                    animal.getCor(),
                    animal.getNascimento(),
                    animal.getTutor().getNome()
            };

            modelo.addRow(linha);
        }

        JTable tabela = new JTable(modelo);

        JScrollPane scroll = new JScrollPane(tabela);

        add(scroll);

        JButton btnExcluir = new JButton("Excluir Animal");
        JButton btnEditar = new JButton("Editar Animal");

        JPanel painelBotoes = new JPanel();

        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);

        add(painelBotoes, BorderLayout.SOUTH);

        btnExcluir.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione um animal para excluir!");
                return;
            }

            int confirmacao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente excluir este animal?",
                    "Confirmar exclusão",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirmacao == JOptionPane.YES_OPTION) {

                int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

                int id = (int) modelo.getValueAt(linhaModelo, 0);

                AnimalDAO dao = new AnimalDAO();

                if (dao.excluir(id)) {

                    modelo.removeRow(linhaModelo);

                    JOptionPane.showMessageDialog(this,
                            "Animal excluído com sucesso!");

                } else {

                    JOptionPane.showMessageDialog(this,
                            "Erro ao excluir animal!");
                }
            }
        });

        btnEditar.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione um animal para editar!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idAnimal = (int) modelo.getValueAt(linhaModelo, 0);

            Animal animalSelecionado = null;

            for (Animal animal : animais) {
                if (animal.getId() == idAnimal) {
                    animalSelecionado = animal;
                    break;
                }
            }

            if (animalSelecionado == null) {
                JOptionPane.showMessageDialog(this,
                        "Animal não encontrado!");
                return;
            }

            final int linhaEdicao = tabela.convertRowIndexToModel(
                    linhaSelecionada
            );

            final Animal animalEdicao = animalSelecionado;

            TelaEditarAnimal telaEdicao = new TelaEditarAnimal(animalEdicao, () -> {

                modelo.setValueAt(animalEdicao.getNome(), linhaEdicao, 1);
                modelo.setValueAt(animalEdicao.getSexo(), linhaEdicao, 4);
                modelo.setValueAt(animalEdicao.getCor(), linhaEdicao, 5);
                modelo.setValueAt(animalEdicao.getNascimento(), linhaEdicao, 6);
                modelo.setValueAt(animalEdicao.getRaca().getNome(), linhaEdicao, 3);

            });
            telaEdicao.setVisible(true);

        });

    }
}