package view;

import dao.EspecieDAO;
import dao.RacaDAO;
import model.Especie;
import model.Raca;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaEditarRaca extends JFrame {

    private JTextField campoNome;
    private JComboBox<String> comboEspecie;

    public TelaEditarRaca(Raca raca, Runnable aoSalvar) {

        setTitle("PetCare - Editar Raça");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(3, 2, 10, 10));

        // Nome atual da raça
        add(new JLabel("Nome da Raça:"));

        campoNome = new JTextField(raca.getNome());
        add(campoNome);

        // Lista de espécies
        add(new JLabel("Espécie:"));

        comboEspecie = new JComboBox<>();

        EspecieDAO especieDAO = new EspecieDAO();
        List<Especie> especies = especieDAO.listar();

        int indiceAtual = -1;

        for (int i = 0; i < especies.size(); i++) {

            Especie especie = especies.get(i);

            comboEspecie.addItem(especie.getNome());

            if (especie.getId() == raca.getIdEspecie()) {
                indiceAtual = i;
            }
        }

        if (indiceAtual >= 0) {
            comboEspecie.setSelectedIndex(indiceAtual);
        }

        add(comboEspecie);

        // Botões
        JButton btnCancelar = new JButton("Cancelar");
        JButton btnSalvar = new JButton("Salvar Alterações");

        add(btnCancelar);
        add(btnSalvar);

        btnCancelar.addActionListener(e -> dispose());

        btnSalvar.addActionListener(e -> {

            String nome = campoNome.getText().trim();

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Informe o nome da raça!");
                return;
            }

            int indice = comboEspecie.getSelectedIndex();

            if (indice < 0) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma espécie!");
                return;
            }

            Especie especieSelecionada = especies.get(indice);

            RacaDAO dao = new RacaDAO();

            // Impedir mudança de espécie quando houver animais
            if (especieSelecionada.getId() != raca.getIdEspecie()
                    && dao.possuiAnimais(raca.getId())) {

                JOptionPane.showMessageDialog(this,
                        "Não é possível alterar a espécie!\n" +
                                "Esta raça possui animais vinculados.");
                return;
            }

            Raca racaAtualizada = new Raca();

            racaAtualizada.setId(raca.getId());
            racaAtualizada.setNome(nome);
            racaAtualizada.setEspecie(especieSelecionada);

            if (dao.atualizar(racaAtualizada)) {

                raca.setNome(nome);
                raca.setEspecie(especieSelecionada);

                JOptionPane.showMessageDialog(this,
                        "Raça atualizada com sucesso!");

                if (aoSalvar != null) {
                    aoSalvar.run();
                }

                dispose();

            } else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao atualizar raça!");
            }
        });
    }
}