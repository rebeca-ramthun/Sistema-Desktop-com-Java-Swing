package view;

import controller.EspecieController;

import javax.swing.*;
import java.awt.*;

public class TelaCadastroEspecie extends JFrame {

    private JTextField campoNome;

    public TelaCadastroEspecie() {

        setTitle("PetCare - Cadastrar Espécie");
        setSize(450, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(2, 2, 10, 10));

        // Campo para informar a espécie
        add(new JLabel("Nome da Espécie:"));

        campoNome = new JTextField();
        add(campoNome);

        // Botões
        JButton btnLimpar = new JButton("Limpar");
        JButton btnCadastrar = new JButton("Cadastrar");

        add(btnLimpar);
        add(btnCadastrar);

        // Limpar o campo
        btnLimpar.addActionListener(e -> {
            campoNome.setText("");
            campoNome.requestFocus();
        });

        // Cadastrar espécie
        btnCadastrar.addActionListener(e -> {

            String nome = campoNome.getText();

            EspecieController controller = new EspecieController();

            String mensagem = controller.cadastrarEspecie(nome);

            JOptionPane.showMessageDialog(this, mensagem);

            if (mensagem.equals("Espécie cadastrada com sucesso!")) {
                campoNome.setText("");
                campoNome.requestFocus();
            }
        });
    }
}