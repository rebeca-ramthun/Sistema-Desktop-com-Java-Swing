package view;

import model.Animal;
import dao.AnimalDAO;
import dao.RacaDAO;
import model.Raca;
import java.util.List;


import javax.swing.*;
import java.awt.*;

public class TelaEditarAnimal extends JFrame {

    private JTextField campoNome;
    private JTextField campoCor;
    private JTextField campoNascimento;
    private JComboBox<String> campoSexo;
    private JComboBox<String> campoRaca;

    public TelaEditarAnimal(Animal animal, Runnable aoSalvar) {

        setTitle("PetCare - Editar Animal");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new GridLayout(6, 2, 10, 10));

        add(new JLabel("Nome:"));
        campoNome = new JTextField();
        add(campoNome);

        add(new JLabel("Raça:"));

        campoRaca = new JComboBox<>();
        campoRaca.setEditable(false);

        add(campoRaca);

        RacaDAO racaDAO = new RacaDAO();

        List<Raca> racas = racaDAO.listarPorEspecie(
                animal.getEspecie().getId()
        );

        for (Raca raca : racas) {
            campoRaca.addItem(raca.getNome());
        }

        add(new JLabel("Sexo:"));
        campoSexo = new JComboBox<>(
                new String[]{"Macho", "Fêmea"}
        );
        add(campoSexo);

        add(new JLabel("Cor:"));
        campoCor = new JTextField();
        add(campoCor);

        add(new JLabel("Nascimento (AAAA-MM-DD):"));
        campoNascimento = new JTextField();
        add(campoNascimento);

        JButton btnSalvar = new JButton("Salvar Alterações");
        add(btnSalvar);
        btnSalvar.addActionListener(e -> {

            animal.setNome(campoNome.getText().trim());
            animal.setSexo((String) campoSexo.getSelectedItem());
            animal.setCor(campoCor.getText().trim());
            animal.setNascimento(campoNascimento.getText().trim());

            String nomeRaca = (String) campoRaca.getSelectedItem();

            if (nomeRaca == null) {
                JOptionPane.showMessageDialog(this,
                        "Nenhuma raça disponível para essa espécie!");
                return;
            }

            int idEspecie = animal.getEspecie().getId();

            int idRaca = racaDAO.buscarIdPorNome(nomeRaca, idEspecie);

            if (idRaca == -1) {
                JOptionPane.showMessageDialog(this,
                        "Raça não encontrada para essa espécie!");
                return;
            }

            animal.getRaca().setId(idRaca);
            animal.getRaca().setNome(nomeRaca);

            AnimalDAO dao = new AnimalDAO();

            if (dao.atualizar(animal)) {

                JOptionPane.showMessageDialog(this,
                        "Animal atualizado com sucesso!");

                if (aoSalvar != null) {
                    aoSalvar.run();
                }

                dispose();
            }
            else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao atualizar animal! Verifique os dados.");
            }
        });

        campoNome.setText(animal.getNome());
        campoSexo.setSelectedItem(animal.getSexo());
        campoCor.setText(animal.getCor());
        campoNascimento.setText(animal.getNascimento());
        campoRaca.setSelectedItem(animal.getRaca().getNome());
    }
}