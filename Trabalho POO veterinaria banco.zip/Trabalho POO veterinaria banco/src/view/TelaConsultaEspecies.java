package view;

import dao.EspecieDAO;
import model.Especie;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaConsultaEspecies extends JFrame {

    public TelaConsultaEspecies() {

        setTitle("PetCare - Consultar Espécies");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Criar a tabela
        String[] colunas = {"ID", "Nome da Espécie"};

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }
        };

        // Buscar as espécies no banco
        EspecieDAO especieDAO = new EspecieDAO();
        List<Especie> especies = especieDAO.listar();

        // Preencher a tabela
        for (Especie especie : especies) {

            Object[] linha = {
                    especie.getId(),
                    especie.getNome()
            };

            modelo.addRow(linha);
        }

        JTable tabela = new JTable(modelo);

        tabela.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        JScrollPane scroll = new JScrollPane(tabela);

        add(scroll, BorderLayout.CENTER);

        // Botões
        JButton btnEditar = new JButton("Editar Espécie");
        JButton btnExcluir = new JButton("Excluir Espécie");

        btnExcluir.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma espécie para excluir!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idEspecie = (int) modelo.getValueAt(linhaModelo, 0);

            EspecieDAO dao = new EspecieDAO();

            // Verificar vínculos com animais e raças
            if (dao.possuiVinculos(idEspecie)) {
                JOptionPane.showMessageDialog(this,
                        "Não é possível excluir esta espécie!\n" +
                                "Ela possui animais ou raças vinculados.");
                return;
            }

            // Solicitar confirmação
            int confirmacao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente excluir esta espécie?",
                    "Confirmar Exclusão",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirmacao == JOptionPane.YES_OPTION) {

                if (dao.excluir(idEspecie)) {

                    // Remover da tabela
                    modelo.removeRow(linhaModelo);

                    // Remover da lista em memória
                    especies.removeIf(
                            especie -> especie.getId() == idEspecie
                    );

                    JOptionPane.showMessageDialog(this,
                            "Espécie excluída com sucesso!");

                } else {
                    JOptionPane.showMessageDialog(this,
                            "Erro ao excluir espécie!");
                }
            }
        });

        JPanel painelBotoes = new JPanel();

        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);

        add(painelBotoes, BorderLayout.SOUTH);

        btnEditar.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma espécie para editar!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idEspecie = (int) modelo.getValueAt(linhaModelo, 0);

            Especie especieSelecionada = null;

            for (Especie especie : especies) {
                if (especie.getId() == idEspecie) {
                    especieSelecionada = especie;
                    break;
                }
            }

            if (especieSelecionada == null) {
                JOptionPane.showMessageDialog(this,
                        "Espécie não encontrada!");
                return;
            }

            final Especie especieEdicao = especieSelecionada;

            TelaEditarEspecie telaEdicao = new TelaEditarEspecie(
                    especieEdicao,
                    () -> {
                        modelo.setValueAt(
                                especieEdicao.getNome(),
                                linhaModelo,
                                1
                        );
                    }
            );

            telaEdicao.setVisible(true);

        });
    }
}