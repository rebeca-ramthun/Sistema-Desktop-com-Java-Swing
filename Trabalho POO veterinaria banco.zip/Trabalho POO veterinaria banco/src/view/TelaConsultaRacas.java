package view;

import dao.RacaDAO;
import model.Raca;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaConsultaRacas extends JFrame {

    public TelaConsultaRacas() {

        setTitle("PetCare - Consultar Raças");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Criar a tabela
        String[] colunas = {"ID", "Raça", "Espécie"};

        DefaultTableModel modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }
        };

        // Buscar raças no banco
        RacaDAO racaDAO = new RacaDAO();
        List<Raca> racas = racaDAO.listar();

        // Preencher a tabela
        for (Raca raca : racas) {

            Object[] linha = {
                    raca.getId(),
                    raca.getNome(),
                    raca.getEspecie().getNome()
            };

            modelo.addRow(linha);
        }

        JTable tabela = new JTable(modelo);

        tabela.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        JScrollPane scroll = new JScrollPane(tabela);
        add(scroll, BorderLayout.CENTER);

        // Botões
        JButton btnEditar = new JButton("Editar Raça");
        JButton btnExcluir = new JButton("Excluir Raça");

        btnExcluir.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma raça para excluir!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idRaca = (int) modelo.getValueAt(linhaModelo, 0);
            String nomeRaca = modelo.getValueAt(linhaModelo, 1).toString();

            // Verificar se existem animais vinculados
            if (racaDAO.possuiAnimais(idRaca)) {
                JOptionPane.showMessageDialog(this,
                        "Não é possível excluir a raça " + nomeRaca + "!\n"
                                + "Existem animais vinculados a ela.");
                return;
            }

            // Pedir confirmação
            int confirmacao = JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente excluir a raça " + nomeRaca + "?",
                    "Confirmar Exclusão",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirmacao != JOptionPane.YES_OPTION) {
                return;
            }

            // Excluir no banco
            if (racaDAO.excluir(idRaca)) {

                JOptionPane.showMessageDialog(this,
                        "Raça excluída com sucesso!");

                // Atualizar a tabela
                modelo.setRowCount(0);

                racas.clear();
                racas.addAll(racaDAO.listar());

                for (Raca raca : racas) {
                    modelo.addRow(new Object[]{
                            raca.getId(),
                            raca.getNome(),
                            raca.getEspecie().getNome()
                    });
                }

            } else {
                JOptionPane.showMessageDialog(this,
                        "Não foi possível excluir a raça!");
            }
        });

        btnEditar.addActionListener(e -> {

            int linhaSelecionada = tabela.getSelectedRow();

            if (linhaSelecionada == -1) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma raça para editar!");
                return;
            }

            int linhaModelo = tabela.convertRowIndexToModel(linhaSelecionada);

            int idRaca = (int) modelo.getValueAt(linhaModelo, 0);

            Raca racaSelecionada = null;

            for (Raca raca : racas) {
                if (raca.getId() == idRaca) {
                    racaSelecionada = raca;
                    break;
                }
            }

            if (racaSelecionada == null) {
                JOptionPane.showMessageDialog(this,
                        "Raça não encontrada!");
                return;
            }

            TelaEditarRaca telaEditar = new TelaEditarRaca(
                    racaSelecionada,
                    () -> {
                        modelo.setRowCount(0);

                        racas.clear();
                        racas.addAll(racaDAO.listar());

                        for (Raca raca : racas) {
                            modelo.addRow(new Object[]{
                                    raca.getId(),
                                    raca.getNome(),
                                    raca.getEspecie().getNome()
                            });
                        }
                    }
            );

            telaEditar.setVisible(true);
        });

        JPanel painelBotoes = new JPanel();

        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);

        add(painelBotoes, BorderLayout.SOUTH);
    }
}