package view;

import controller.TutorController;

import javax.swing.*;
import java.awt.*;

public class TelaCadastroTutor extends JFrame {

    private JTextField campoNome;
    private JTextField campoTelefone;

    public TelaCadastroTutor() {

        setTitle("PetCare - Cadastro de Tutor");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new GridLayout(3, 2, 10, 10));

        add(new JLabel("Nome do Tutor:"));
        campoNome = new JTextField();
        add(campoNome);

        add(new JLabel("Telefone:"));
        campoTelefone = new JTextField();
        add(campoTelefone);

        JButton btnLimpar = new JButton("Limpar");
        JButton btnCadastrar = new JButton("Cadastrar");

        add(btnLimpar);
        add(btnCadastrar);

        btnCadastrar.addActionListener(e -> {

            String nome = campoNome.getText();
            String telefone = campoTelefone.getText();

            TutorController controller = new TutorController();

            String mensagem = controller.cadastrarTutor(nome, telefone);

            JOptionPane.showMessageDialog(this, mensagem);

            if (mensagem.equals("Tutor cadastrado com sucesso!")) {
                campoNome.setText("");
                campoTelefone.setText("");
            }
        });

    }
}