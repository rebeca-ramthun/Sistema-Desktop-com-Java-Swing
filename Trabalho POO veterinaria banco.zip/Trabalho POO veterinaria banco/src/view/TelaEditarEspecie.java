package view;

import dao.EspecieDAO;
import model.Especie;

import javax.swing.*;
import java.awt.*;

public class TelaEditarEspecie extends JFrame {

    private JTextField campoNome;

    public TelaEditarEspecie(Especie especie, Runnable aoSalvar) {

        setTitle("PetCare - Editar Espécie");
        setSize(450, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(2, 2, 10, 10));

        // Campo com o nome atual da espécie
        add(new JLabel("Nome da Espécie:"));

        campoNome = new JTextField(especie.getNome());
        add(campoNome);

        // Botões
        JButton btnCancelar = new JButton("Cancelar");
        JButton btnSalvar = new JButton("Salvar Alterações");

        add(btnCancelar);
        add(btnSalvar);

        // Cancelar edição
        btnCancelar.addActionListener(e -> dispose());

        // Salvar alterações
        btnSalvar.addActionListener(e -> {

            String nome = campoNome.getText().trim();

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Informe o nome da espécie!");
                return;
            }

            Especie especieAtualizada = new Especie();

            especieAtualizada.setId(especie.getId());
            especieAtualizada.setNome(nome);

            EspecieDAO dao = new EspecieDAO();

            if (dao.atualizar(especieAtualizada)) {

                // Atualizar o objeto original
                especie.setNome(nome);

                JOptionPane.showMessageDialog(this,
                        "Espécie atualizada com sucesso!");

                // Avisar a tela de consulta
                if (aoSalvar != null) {
                    aoSalvar.run();
                }

                dispose();

            } else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao atualizar espécie!");
            }
        });
    }
}