package view;

import dao.TutorDAO;
import model.Tutor;

import javax.swing.*;
import java.awt.*;

public class TelaEditarTutor extends JFrame {

    private JTextField campoNome;
    private JTextField campoTelefone;

    public TelaEditarTutor(Tutor tutor, Runnable aoSalvar) {

        setTitle("PetCare - Editar Tutor");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new GridLayout(3, 2, 10, 10));

        add(new JLabel("Nome do Tutor:"));
        campoNome = new JTextField(tutor.getNome());
        add(campoNome);

        add(new JLabel("Telefone:"));
        campoTelefone = new JTextField(tutor.getTelefone());
        add(campoTelefone);

        JButton btnCancelar = new JButton("Cancelar");
        JButton btnSalvar = new JButton("Salvar Alterações");

        add(btnCancelar);
        add(btnSalvar);

        btnCancelar.addActionListener(e -> dispose());

        btnSalvar.addActionListener(e -> {

            String nome = campoNome.getText().trim();
            String telefone = campoTelefone.getText().trim();

            if (nome.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Informe o nome do tutor!");
                return;
            }

            if (!telefone.matches("\\d{10,11}")) {
                JOptionPane.showMessageDialog(this,
                        "O telefone deve conter 10 ou 11 números!");
                return;
            }

            Tutor tutorAtualizado = new Tutor();
            tutorAtualizado.setId(tutor.getId());
            tutorAtualizado.setNome(nome);
            tutorAtualizado.setTelefone(telefone);

            TutorDAO dao = new TutorDAO();

            if (dao.atualizar(tutorAtualizado)) {

                tutor.setNome(nome);
                tutor.setTelefone(telefone);

                JOptionPane.showMessageDialog(this,
                        "Tutor atualizado com sucesso!");

                if (aoSalvar != null) {
                    aoSalvar.run();
                }

                dispose();

            } else {
                JOptionPane.showMessageDialog(this,
                        "Erro ao atualizar tutor!");
            }
        });
    }
}
