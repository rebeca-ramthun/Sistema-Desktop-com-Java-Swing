package view;

import controller.RacaController;
import dao.EspecieDAO;
import model.Especie;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaCadastroRaca extends JFrame {

    private JTextField campoNome;
    private JComboBox<String> comboEspecie;
    private List<Especie> especies;

    public TelaCadastroRaca() {

        setTitle("PetCare - Cadastrar Raça");
        setSize(450, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(3, 2, 10, 10));

        // Campo nome da raça
        add(new JLabel("Nome da Raça:"));

        campoNome = new JTextField();
        add(campoNome);

        // Lista de espécies
        add(new JLabel("Espécie:"));

        comboEspecie = new JComboBox<>();
        comboEspecie.addItem("Selecione uma espécie");

        EspecieDAO especieDAO = new EspecieDAO();
        especies = especieDAO.listar();

        for (Especie especie : especies) {
            comboEspecie.addItem(especie.getNome());
        }

        add(comboEspecie);

        // Botões
        JButton btnLimpar = new JButton("Limpar");
        JButton btnCadastrar = new JButton("Cadastrar");

        add(btnLimpar);
        add(btnCadastrar);

        // Limpar os campos
        btnLimpar.addActionListener(e -> {
            campoNome.setText("");
            comboEspecie.setSelectedIndex(0);
            campoNome.requestFocus();
        });

        // Cadastrar raça
        btnCadastrar.addActionListener(e -> {

            String nome = campoNome.getText().trim();

            int indice = comboEspecie.getSelectedIndex();

            if (indice <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Selecione uma espécie!");
                return;
            }

            // O índice 0 é a opção "Selecione uma espécie"
            Especie especieSelecionada = especies.get(indice - 1);

            int idEspecie = especieSelecionada.getId();

            RacaController controller = new RacaController();

            String mensagem = controller.cadastrarRaca(
                    nome, idEspecie
            );

            JOptionPane.showMessageDialog(this, mensagem);

            if (mensagem.equals("Raça cadastrada com sucesso!")) {
                campoNome.setText("");
                comboEspecie.setSelectedIndex(0);
                campoNome.requestFocus();
            }
        });
    }
}