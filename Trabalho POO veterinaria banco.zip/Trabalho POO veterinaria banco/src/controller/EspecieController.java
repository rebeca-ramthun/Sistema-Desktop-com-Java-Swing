package controller;

import dao.EspecieDAO;
import model.Especie;

public class EspecieController {

    public String cadastrarEspecie(String nome) {

        // Remover espaços desnecessários
        nome = nome.trim();

        // Validar o nome
        if (nome.isEmpty()) {
            return "Informe o nome da espécie!";
        }

        // Criar o objeto Especie
        Especie especie = new Especie();
        especie.setNome(nome);

        // Salvar no banco de dados
        EspecieDAO dao = new EspecieDAO();

        if (dao.cadastrar(especie)) {
            return "Espécie cadastrada com sucesso!";
        } else {
            return "Erro ao cadastrar espécie!";
        }
    }
}