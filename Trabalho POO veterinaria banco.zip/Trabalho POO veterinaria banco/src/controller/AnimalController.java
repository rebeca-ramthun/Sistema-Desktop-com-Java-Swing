package controller;

import dao.AnimalDAO;
import dao.EspecieDAO;
import dao.RacaDAO;
import dao.TutorDAO;

import model.Animal;
import model.Especie;
import model.Raca;
import model.Tutor;

public class AnimalController {
    private AnimalDAO animalDAO = new AnimalDAO();
    private TutorDAO tutorDAO = new TutorDAO();
    private EspecieDAO especieDAO = new EspecieDAO();
    private RacaDAO racaDAO = new RacaDAO();

    public String cadastrarAnimal(
            String nome,
            String especie,
            String raca,
            String sexo,
            String cor,
            String nascimento,
            String tutor,
            String telefone) {

        int idEspecie = especieDAO.buscarIdPorNome(especie);

        if (idEspecie == -1) {
            return "Espécie não encontrada!";
        }

        int idRaca = racaDAO.buscarIdPorNome(raca, idEspecie);

        if (idRaca == -1) {
            return "Raça não encontrada para essa espécie!";
        }

        int idTutor = tutorDAO.buscarIdPorNome(tutor);

        if (idTutor == -1) {
            return "Tutor não encontrado!";
        }

        Animal animal = new Animal();

        animal.setNome(nome);
        animal.setSexo(sexo);
        animal.setCor(cor);
        animal.setNascimento(nascimento);

        Especie objEspecie = new Especie();
        objEspecie.setId(idEspecie);
        animal.setEspecie(objEspecie);

        Raca objRaca = new Raca();
        objRaca.setId(idRaca);
        animal.setRaca(objRaca);

        Tutor objTutor = new Tutor();
        objTutor.setId(idTutor);
        animal.setTutor(objTutor);

        if (animalDAO.cadastrar(animal)) {
            return "Animal cadastrado com sucesso!";
        }

        return "Erro ao cadastrar animal!";
    }
}