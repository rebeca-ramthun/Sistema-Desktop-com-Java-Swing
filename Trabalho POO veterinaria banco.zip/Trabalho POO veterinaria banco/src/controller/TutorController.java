package controller;

import dao.TutorDAO;
import model.Tutor;

public class TutorController {

    private TutorDAO tutorDAO = new TutorDAO();

    public String cadastrarTutor(String nome, String telefone) {

        nome = nome.trim();
        telefone = telefone.trim();

        if (nome.isEmpty()) {
            return "Informe o nome do tutor!";
        }

        if (telefone.isEmpty()) {
            return "Informe o telefone do tutor!";
        }

        if (!telefone.matches("\\d{10,11}")) {
            return "O telefone deve conter 10 ou 11 números!";
        }

        Tutor tutor = new Tutor();

        tutor.setNome(nome);
        tutor.setTelefone(telefone);

        if (tutorDAO.cadastrar(tutor)) {
            return "Tutor cadastrado com sucesso!";
        }

        return "Erro ao cadastrar tutor!";
    }
}