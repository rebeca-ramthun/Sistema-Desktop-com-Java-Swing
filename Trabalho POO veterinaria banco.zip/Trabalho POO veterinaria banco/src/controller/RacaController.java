package controller;

import dao.RacaDAO;
import model.Raca;
import model.Especie;

public class RacaController {

    public String cadastrarRaca(String nome, int idEspecie) {

        // Validar o nome
        if (nome == null || nome.trim().isEmpty()) {
            return "Informe o nome da raça!";
        }

        // Validar a espécie selecionada
        if (idEspecie <= 0) {
            return "Selecione uma espécie!";
        }

        // Criar o objeto Especie
        Especie especie = new Especie();
        especie.setId(idEspecie);

        // Criar o objeto Raca
        Raca raca = new Raca();
        raca.setNome(nome.trim());
        raca.setEspecie(especie);

        // Cadastrar no banco de dados
        RacaDAO dao = new RacaDAO();

        if (dao.cadastrar(raca)) {
            return "Raça cadastrada com sucesso!";
        } else {
            return "Erro ao cadastrar raça!";
        }
    }
}