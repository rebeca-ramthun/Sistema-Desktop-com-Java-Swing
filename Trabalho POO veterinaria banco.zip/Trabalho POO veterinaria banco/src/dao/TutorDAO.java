package dao;

import database.Conexao;
import model.Tutor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;

public class TutorDAO {
    public boolean cadastrar(Tutor tutor) {

        String sql = "INSERT INTO tutor (nome, telefone) VALUES (?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, tutor.getNome());
            stmt.setString(2, tutor.getTelefone());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar tutor: " + e.getMessage());
            return false;
        }
    }
    public int buscarIdPorNome(String nome) {

        String sql = "SELECT id_tutor FROM tutor WHERE nome = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, nome);

            ResultSet resultado = stmt.executeQuery();

            if (resultado.next()) {
                return resultado.getInt("id_tutor");
            }

        } catch (SQLException e) {
            System.out.println("Erro ao buscar tutor: " + e.getMessage());
        }

        return -1;
    }
    public List<Tutor> listar() {

        List<Tutor> tutores = new ArrayList<>();

        String sql = "SELECT id_tutor, nome, telefone FROM tutor ORDER BY nome";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                Tutor tutor = new Tutor();

                tutor.setId(resultado.getInt("id_tutor"));
                tutor.setNome(resultado.getString("nome"));
                tutor.setTelefone(resultado.getString("telefone"));

                tutores.add(tutor);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar tutores: " + e.getMessage());
        }

        return tutores;
    }

    public boolean atualizar(Tutor tutor) {

        String sql = "UPDATE tutor SET nome = ?, telefone = ? " +
                "WHERE id_tutor = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, tutor.getNome());
            stmt.setString(2, tutor.getTelefone());
            stmt.setInt(3, tutor.getId());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar tutor: " + e.getMessage());
            return false;
        }
    }

    public boolean excluir(int id) {

        String sql = "DELETE FROM tutor WHERE id_tutor = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao excluir tutor: " + e.getMessage());
            return false;
        }
    }

    public boolean possuiAnimais(int idTutor) {

        String sql = "SELECT COUNT(*) FROM animal WHERE id_tutor = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idTutor);

            try (ResultSet resultado = stmt.executeQuery()) {

                if (resultado.next()) {
                    return resultado.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao verificar animais: " + e.getMessage());

            // Por segurança, impede a exclusão se ocorrer um erro.
            return true;
        }

        return false;
    }
}
