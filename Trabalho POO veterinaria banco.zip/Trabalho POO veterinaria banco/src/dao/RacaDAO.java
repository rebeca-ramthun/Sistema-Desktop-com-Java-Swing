package dao;

import database.Conexao;
import model.Raca;
import model.Especie;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class RacaDAO {
    public int buscarIdPorNome(String nome, int idEspecie) {

        String sql = "SELECT id_raca FROM raca " +
                "WHERE nome = ? AND id_especie = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setInt(2, idEspecie);

            try (ResultSet resultado = stmt.executeQuery()) {

                if(resultado.next()){
                    return resultado.getInt("id_raca");
                }
            }
        }
        catch (SQLException e) {
            System.out.println("Erro ao buscar raça: " + e.getMessage());
        }
        return -1;

    }

    public List<Raca> listarPorEspecie(int idEspecie) {

        List<Raca> racas = new ArrayList<>();

        String sql = "SELECT id_raca, nome FROM raca " +
                "WHERE id_especie = ? ORDER BY nome";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idEspecie);

            try (ResultSet resultado = stmt.executeQuery()) {

                while (resultado.next()) {

                    Raca raca = new Raca();

                    raca.setId(resultado.getInt("id_raca"));
                    raca.setNome(resultado.getString("nome"));

                    racas.add(raca);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar raças: " + e.getMessage());
        }

        return racas;
    }

    public boolean cadastrar(Raca raca) {

        String sql = "INSERT INTO raca (nome, id_especie) VALUES (?, ?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, raca.getNome());
            stmt.setInt(2, raca.getIdEspecie());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {

            System.out.println("Erro ao cadastrar raça: " + e.getMessage());

            return false;
        }
    }

    public List<Raca> listar() {

        List<Raca> racas = new ArrayList<>();

        String sql = """
            SELECT
                r.id_raca,
                r.nome AS nome_raca,
                e.id_especie,
                e.nome AS nome_especie
            FROM raca r
            INNER JOIN especie e
                ON r.id_especie = e.id_especie
            ORDER BY e.nome, r.nome
            """;

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                Especie especie = new Especie();
                especie.setId(resultado.getInt("id_especie"));
                especie.setNome(resultado.getString("nome_especie"));

                Raca raca = new Raca();
                raca.setId(resultado.getInt("id_raca"));
                raca.setNome(resultado.getString("nome_raca"));
                raca.setEspecie(especie);

                racas.add(raca);
            }

        } catch (SQLException e) {
            System.out.println(
                    "Erro ao listar raças: " + e.getMessage()
            );
        }

        return racas;
    }

    public boolean atualizar(Raca raca) {

        String sql = "UPDATE raca SET nome = ?, id_especie = ? "
                + "WHERE id_raca = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, raca.getNome());
            stmt.setInt(2, raca.getIdEspecie());
            stmt.setInt(3, raca.getId());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Erro ao atualizar raça: " + e.getMessage()
            );

            return false;
        }
    }

    public boolean possuiAnimais(int idRaca) {

        String sql = "SELECT COUNT(*) FROM animal WHERE id_raca = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idRaca);

            try (ResultSet resultado = stmt.executeQuery()) {

                if (resultado.next()) {
                    return resultado.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.out.println(
                    "Erro ao verificar animais da raça: " + e.getMessage()
            );

            // Por segurança, impede a alteração se a consulta falhar.
            return true;
        }

        return false;
    }

    public boolean excluir(int idRaca) {

        // Impede a exclusão de raças vinculadas a animais
        if (possuiAnimais(idRaca)) {
            return false;
        }

        String sql = "DELETE FROM raca WHERE id_raca = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idRaca);

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Erro ao excluir raça: " + e.getMessage()
            );

            return false;
        }
    }
}