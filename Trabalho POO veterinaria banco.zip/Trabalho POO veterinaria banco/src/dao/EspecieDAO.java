package dao;

import database.Conexao;
import model.Especie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EspecieDAO {
    public int buscarIdPorNome(String nome){
        String sql = "SELECT id_especie FROM especie WHERE nome = ?";

        try (Connection conexao = Conexao.conectar();
        PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, nome);

            try (ResultSet resultado = stmt.executeQuery()) {
                if (resultado.next()) {
                    return resultado.getInt("id_especie");
                }
            }
        }
        catch (SQLException e) {
            System.out.println("Erro ao buscar espécie: " + e.getMessage());
        }

        return -1;
    }

    public boolean cadastrar(Especie especie) {

        String sql = "INSERT INTO especie (nome) VALUES (?)";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, especie.getNome());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar espécie: " + e.getMessage());
            return false;
        }
    }

    public List<Especie> listar() {

        List<Especie> especies = new ArrayList<>();

        String sql = "SELECT id_especie, nome FROM especie ORDER BY nome";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet resultado = stmt.executeQuery()) {

            while (resultado.next()) {

                Especie especie = new Especie();

                especie.setId(resultado.getInt("id_especie"));
                especie.setNome(resultado.getString("nome"));

                especies.add(especie);
            }

        } catch (SQLException e) {
            System.out.println("Erro ao listar espécies: " + e.getMessage());
        }

        return especies;
    }

    public boolean atualizar(Especie especie) {

        String sql = "UPDATE especie SET nome = ? WHERE id_especie = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, especie.getNome());
            stmt.setInt(2, especie.getId());

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao atualizar espécie: " + e.getMessage());
            return false;
        }
    }

    public boolean excluir(int idEspecie) {

        String sql = "DELETE FROM especie WHERE id_especie = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idEspecie);

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {

            System.out.println(
                    "Erro ao excluir espécie: " + e.getMessage()
            );

            return false;
        }
    }

    public boolean possuiVinculos(int idEspecie) {

        String sql = """
            SELECT
                (SELECT COUNT(*) FROM animal
                 WHERE id_especie = ?)
                +
                (SELECT COUNT(*) FROM raca
                 WHERE id_especie = ?)
            AS total
            """;

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, idEspecie);
            stmt.setInt(2, idEspecie);

            try (ResultSet resultado = stmt.executeQuery()) {

                if (resultado.next()) {
                    return resultado.getInt("total") > 0;
                }
            }

        } catch (SQLException e) {

            System.out.println(
                    "Erro ao verificar vínculos da espécie: "
                            + e.getMessage()
            );

            // Em caso de erro, bloquear a exclusão por segurança.
            return true;
        }

        return false;
    }
}
