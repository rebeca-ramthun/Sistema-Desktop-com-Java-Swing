package dao;

import database.Conexao;
import model.Animal;
import model.Especie;
import model.Raca;
import model.Tutor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class AnimalDAO {
    public boolean excluir(int id) {

        String sql = "DELETE FROM animal WHERE id_animal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            int linhasAfetadas = stmt.executeUpdate();

            return linhasAfetadas > 0;

        } catch (SQLException e) {
            System.out.println("Erro ao excluir animal: " + e.getMessage());
            return false;
        }
    }

    public boolean cadastrar(Animal animal){
        String sql = "INSERT INTO animal" +
                "(nome, sexo, cor, nascimento, id_especie, id_raca, id_tutor)"+
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conexao = Conexao.conectar()){
            PreparedStatement stmt = conexao.prepareStatement(sql);

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getSexo());
            stmt.setString(3, animal.getCor());
            stmt.setDate(4, java.sql.Date.valueOf(animal.getNascimento()));
            stmt.setInt(5, animal.getEspecie().getId());
            stmt.setInt(6, animal.getRaca().getId());
            stmt.setInt(7, animal.getTutor().getId());

            stmt.executeUpdate();


            System.out.println("Animal cadastrado com sucesso");
            return true;
        }
        catch (SQLException | IllegalArgumentException e) {
            System.out.println("Erro ao cadastrar animal: " + e.getMessage());
            return false;
        }
    }

    public List<Animal> listar(){
        List<Animal> animais = new ArrayList<>();

        String sql = "SELECT a.*, " +
                "e.nome AS nome_especie, " +
                "r.nome AS nome_raca, " +
                "t.nome AS nome_tutor " +
                "FROM animal a " +
                "JOIN especie e ON a.id_especie = e.id_especie " +
                "JOIN raca r ON a.id_raca = r.id_raca " +
                "JOIN tutor t ON a.id_tutor = t.id_tutor";

        try (Connection conexao = Conexao.conectar();
        PreparedStatement stmt = conexao.prepareStatement(sql);
       ResultSet resultado = stmt.executeQuery()){

            while (resultado.next()){
                Animal animal = new Animal();

                animal.setId(resultado.getInt("id_animal"));
                animal.setNome(resultado.getString("nome"));
                animal.setSexo(resultado.getString("sexo"));
                animal.setCor(resultado.getString("cor"));

                java.sql.Date nascimento = resultado.getDate("nascimento");

                if(nascimento != null){
                    animal.setNascimento(nascimento.toString());
                }
                Especie especie = new Especie();
                especie.setId(resultado.getInt("id_especie"));
                especie.setNome(resultado.getString("nome_especie"));
                animal.setEspecie(especie);

                Raca raca = new Raca();
                raca.setNome(resultado.getString("nome_raca"));
                animal.setRaca(raca);

                Tutor tutor = new Tutor();
                tutor.setNome(resultado.getString("nome_tutor"));
                animal.setTutor(tutor);

                animais.add(animal);
            }
        }
        catch (SQLException e) {
            System.out.println("Erro ao listar animais" + e.getMessage());
        }

        return animais;
    }

    public boolean atualizar(Animal animal) {

        String sql = "UPDATE animal SET nome = ?, sexo = ?, " +
                "cor = ?, nascimento = ?, id_raca = ? " +
                "WHERE id_animal = ?";

        try (Connection conexao = Conexao.conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, animal.getNome());
            stmt.setString(2, animal.getSexo());
            stmt.setString(3, animal.getCor());
            stmt.setDate(4, java.sql.Date.valueOf(animal.getNascimento()));
            stmt.setInt(5, animal.getRaca().getId());
            stmt.setInt(6, animal.getId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException | IllegalArgumentException e) {
            System.out.println("Erro ao atualizar animal: " + e.getMessage());
            return false;
        }
    }
}


